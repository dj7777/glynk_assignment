<div class="msg msg-continuation">
    <span></span>
    <div class="message message-chat message-in tail message-chat">
        <div><span class="tail-container">
        </span><!-- react-text: 3083 -->  <!-- /react-text -->
<span class="tail-container highlight"></span><!-- react-text: 3085 -->
         <!-- /react-text --><!-- react-empty: 3086 -->

         <div class="bubble bubble-text copyable-text" data-pre-plain-text="[20:42, 12/16/2017] Narasimha Persi: ">

                <div class="_3zb-j ZhF0n"><span dir="ltr" class="emojitext selectable-text invisible-space copyable-text">
                    <!-- react-text: 3090 -->Okni will come<!-- /react-text --></span></div><div class="bubble-text-meta">

                    <div class="_1DZAH"><span class="_3EFt_">20:42</span></div></div></div><span></span></div></div>
    <!-- react-empty: 3095 --></div>