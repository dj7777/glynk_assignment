import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import image from './chat-background.jpg';

import App from '../components/App';

console.log('app.js running');

export default App;