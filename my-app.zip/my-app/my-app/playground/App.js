import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import image from './chat-background.jpg';

var styles = {
/*   backgroundImage: 'url('+image+')'
 */};

export default App;

